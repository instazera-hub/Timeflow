import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'app.timeflow.timer',
  appName: 'TimeFlow',
  webDir: 'dist',
  android: { backgroundColor: '#071226' },
};
export default config;
