export const FIELD_KEYS = ["days", "weeks", "months", "hours", "minutes", "seconds"] as const;

export type FieldKey = (typeof FIELD_KEYS)[number];
export type DurationParts = Record<FieldKey, number>;
export type Draft = Record<FieldKey, string>;
export type Mode = "idle" | "running" | "paused" | "done";
export type Tone = "ok" | "done" | "error";
export type Theme = "dark" | "light";

export const LIMITS: Record<FieldKey, number> = {
  days: 365000,
  weeks: 52000,
  months: 12000,
  hours: 8760000,
  minutes: 59,
  seconds: 59,
};

export const DEFAULT_PARTS: DurationParts = {
  days: 0,
  weeks: 0,
  months: 0,
  hours: 0,
  minutes: 5,
  seconds: 0,
};

export type PresetIcon = "timer" | "clock" | "hourglass" | "calendar";

export const PRESETS: { id: string; label: string; seconds: number; icon: PresetIcon }[] = [
  { id: "5m", label: "5 minutes", seconds: 300, icon: "timer" },
  { id: "10m", label: "10 minutes", seconds: 600, icon: "timer" },
  { id: "15m", label: "15 minutes", seconds: 900, icon: "clock" },
  { id: "30m", label: "30 minutes", seconds: 1800, icon: "clock" },
  { id: "1h", label: "1 heure", seconds: 3600, icon: "hourglass" },
  { id: "1d", label: "1 jour", seconds: 86400, icon: "calendar" },
  { id: "1w", label: "1 semaine", seconds: 604800, icon: "calendar" },
  { id: "1mo", label: "1 mois", seconds: 2592000, icon: "calendar" },
];

export class DurationError extends Error {}

const STORAGE_KEY = "timeflow.v1";

export type TimerState = {
  parts: DurationParts;
  draft: Draft;
  presetId: string | null;
  initialMs: number;
  remainingMs: number;
  mode: Mode;
  deadline: number | null;
  status: string;
  tone: Tone;
  feedbackTitle: string;
  summary: string;
};

export type Persisted = {
  theme: Theme;
  sound: boolean;
  notify: boolean;
  parts: DurationParts;
  mode: Mode;
  deadline: number | null;
  remainingMs: number;
  initialMs: number;
};

export type TimerAction =
  | { type: "hydrate"; saved: Persisted; now: number }
  | { type: "tick"; now: number }
  | { type: "start"; now: number }
  | { type: "pause"; now: number }
  | { type: "reset"; now: number }
  | { type: "apply"; now: number }
  | { type: "preset"; id: string; seconds: number; now: number }
  | { type: "edit"; key: FieldKey; value: string };

export function partsToDraft(parts: DurationParts): Draft {
  return {
    days: String(parts.days),
    weeks: String(parts.weeks),
    months: String(parts.months),
    hours: String(parts.hours),
    minutes: String(parts.minutes),
    seconds: String(parts.seconds),
  };
}

export function partsFromSeconds(totalSeconds: number): DurationParts {
  const totalMinutes = Math.floor(totalSeconds / 60);
  return {
    months: 0,
    weeks: 0,
    days: 0,
    hours: Math.floor(totalMinutes / 60),
    minutes: totalMinutes % 60,
    seconds: totalSeconds % 60,
  };
}

export function assertParts(parts: DurationParts): void {
  for (const key of FIELD_KEYS) {
    const value = parts[key];
    if (!Number.isSafeInteger(value) || value < 0 || value > LIMITS[key]) {
      throw new DurationError("Veuillez saisir des nombres entiers positifs dans tous les champs.");
    }
  }
  if (parts.minutes > 59 || parts.seconds > 59) {
    throw new DurationError("Les minutes et les secondes doivent être comprises entre 0 et 59.");
  }
}

export function parseDraft(draft: Draft): DurationParts {
  const parts = {} as DurationParts;
  for (const key of FIELD_KEYS) {
    const raw = draft[key].trim();
    const value = Number(raw);
    if (raw === "" || !Number.isSafeInteger(value) || value < 0 || value > LIMITS[key]) {
      throw new DurationError("Veuillez saisir des nombres entiers positifs dans tous les champs.");
    }
    parts[key] = value;
  }
  assertParts(parts);
  return parts;
}

/** Calendar months, with end-of-month clamping (31 Jan + 1 month → 28/29 Feb). */
export function addCalendarMonths(date: Date, count: number): Date {
  const result = new Date(date.getTime());
  if (!count) return result;
  const day = result.getDate();
  result.setDate(1);
  result.setMonth(result.getMonth() + count);
  const lastDay = new Date(result.getFullYear(), result.getMonth() + 1, 0).getDate();
  result.setDate(Math.min(day, lastDay));
  return result;
}

/** Wall-clock duration. Weeks/days are exact 24h blocks; months follow the calendar. */
export function durationMs(parts: DurationParts, now = new Date()): number {
  const target = addCalendarMonths(now, parts.months);
  return (
    target.getTime() -
    now.getTime() +
    (parts.weeks * 7 + parts.days) * 86_400_000 +
    parts.hours * 3_600_000 +
    parts.minutes * 60_000 +
    parts.seconds * 1000
  );
}

export function formatClock(ms: number): string {
  const total = Math.ceil(Math.max(0, ms) / 1000);
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  return [h, m, s].map((n) => String(n).padStart(2, "0")).join(":");
}

export function splitClock(ms: number): { h: string; m: string; s: string } {
  const [h = "00", m = "00", s = "00"] = formatClock(ms).split(":");
  return { h, m, s };
}

export function describe(parts: DurationParts): string {
  const labels: [FieldKey, string, boolean][] = [
    ["months", "mois", false],
    ["weeks", "semaine", true],
    ["days", "jour", true],
    ["hours", "heure", true],
    ["minutes", "minute", true],
    ["seconds", "seconde", true],
  ];
  const bits: string[] = [];
  for (const [key, label, pluralS] of labels) {
    const n = parts[key];
    if (!n) continue;
    bits.push(`${n} ${label}${n > 1 && pluralS ? "s" : ""}`);
  }
  if (bits.length === 0) return "0 seconde";
  if (bits.length === 1) return bits[0] ?? "0 seconde";
  return `${bits.slice(0, -1).join(", ")} et ${bits[bits.length - 1]}`;
}

export function presetIdFor(parts: DurationParts): string | null {
  if (parts.months !== 0 || parts.weeks !== 0 || parts.days !== 0) return null;
  const ms = parts.hours * 3_600_000 + parts.minutes * 60_000 + parts.seconds * 1000;
  return PRESETS.find((preset) => preset.seconds * 1000 === ms)?.id ?? null;
}

function summaryFor(parts: DurationParts, ms: number): string {
  return `${describe(parts)} (${formatClock(ms)})`;
}

function finish(state: TimerState): TimerState {
  return {
    ...state,
    remainingMs: 0,
    mode: "done",
    deadline: null,
    status: "Temps écoulé ! Votre compte à rebours est terminé.",
    tone: "done",
    feedbackTitle: "Compte à rebours terminé",
  };
}

function commit(
  state: TimerState,
  parts: DurationParts,
  now: number,
  message: string,
  presetId: string | null,
): TimerState {
  let ms = 0;
  try {
    assertParts(parts);
    ms = durationMs(parts, new Date(now));
    if (!Number.isFinite(ms) || ms <= 0) {
      throw new DurationError("La durée doit être supérieure à zéro.");
    }
  } catch (error) {
    const messageText = error instanceof Error ? error.message : "Durée invalide.";
    return {
      ...state,
      mode: "idle",
      deadline: null,
      remainingMs: 0,
      initialMs: 0,
      presetId: null,
      status: messageText,
      tone: "error",
      feedbackTitle: "Durée invalide",
      summary: "Vérifiez les valeurs saisies",
    };
  }
  return {
    ...state,
    parts,
    draft: partsToDraft(parts),
    presetId,
    initialMs: ms,
    remainingMs: ms,
    mode: "idle",
    deadline: null,
    status: message,
    tone: "ok",
    feedbackTitle: "Durée enregistrée",
    summary: summaryFor(parts, ms),
  };
}

export function initialTimerState(): TimerState {
  const parts = DEFAULT_PARTS;
  const ms = 300_000;
  return {
    parts,
    draft: partsToDraft(parts),
    presetId: "5m",
    initialMs: ms,
    remainingMs: ms,
    mode: "idle",
    deadline: null,
    status: "Prêt à démarrer",
    tone: "ok",
    feedbackTitle: "Durée enregistrée",
    summary: "5 minutes (00:05:00)",
  };
}

export function reduceTimer(state: TimerState, action: TimerAction): TimerState {
  switch (action.type) {
    case "hydrate": {
      const saved = action.saved;
      let mode = saved.mode;
      let remaining = saved.remainingMs;
      let deadline = saved.deadline;
      if (mode === "running" && typeof deadline === "number") {
        remaining = Math.max(0, deadline - action.now);
        if (remaining <= 0) {
          mode = "done";
          remaining = 0;
          deadline = null;
        }
      }
      if (mode === "done") {
        remaining = 0;
        deadline = null;
      }
      const initialMs = saved.initialMs > 0 ? saved.initialMs : remaining;
      return {
        parts: saved.parts,
        draft: partsToDraft(saved.parts),
        presetId: presetIdFor(saved.parts),
        initialMs,
        remainingMs: mode === "idle" ? initialMs : remaining,
        mode,
        deadline: mode === "running" ? deadline : null,
        status:
          mode === "done"
            ? "Temps écoulé ! Votre compte à rebours est terminé."
            : mode === "running"
              ? "Compte à rebours en cours…"
              : mode === "paused"
                ? "Minuteur en pause."
                : "Prêt à démarrer",
        tone: mode === "done" ? "done" : "ok",
        feedbackTitle:
          mode === "done"
            ? "Compte à rebours terminé"
            : mode === "running"
              ? "Minuteur en cours"
              : mode === "paused"
                ? "Minuteur en pause"
                : "Durée enregistrée",
        summary: summaryFor(saved.parts, initialMs),
      };
    }
    case "tick": {
      if (state.mode !== "running" || state.deadline == null) return state;
      const left = Math.max(0, state.deadline - action.now);
      if (left <= 0) return finish(state);
      if (left === state.remainingMs) return state;
      return { ...state, remainingMs: left };
    }
    case "start": {
      if (state.mode === "running" || state.mode === "done") return state;
      if (state.remainingMs <= 0) {
        return {
          ...state,
          status: "Choisissez d'abord une durée supérieure à zéro.",
          tone: "error",
        };
      }
      return {
        ...state,
        mode: "running",
        deadline: action.now + state.remainingMs,
        status: "Compte à rebours en cours…",
        tone: "ok",
        feedbackTitle: "Minuteur en cours",
      };
    }
    case "pause": {
      if (state.mode !== "running" || state.deadline == null) return state;
      const left = Math.max(0, state.deadline - action.now);
      if (left <= 0) return finish(state);
      return {
        ...state,
        mode: "paused",
        remainingMs: left,
        deadline: null,
        status: "Minuteur en pause.",
        tone: "ok",
        feedbackTitle: "Minuteur en pause",
      };
    }
    case "reset": {
      try {
        const parts = parseDraft(state.draft);
        return commit(state, parts, action.now, "Prêt à démarrer", presetIdFor(parts));
      } catch (error) {
        const messageText = error instanceof Error ? error.message : "Durée invalide.";
        return {
          ...state,
          mode: "idle",
          deadline: null,
          remainingMs: 0,
          initialMs: 0,
          presetId: null,
          status: messageText,
          tone: "error",
          feedbackTitle: "Durée invalide",
          summary: "Vérifiez les valeurs saisies",
        };
      }
    }
    case "apply": {
      if (state.mode === "running") return state;
      try {
        const parts = parseDraft(state.draft);
        return commit(state, parts, action.now, "Durée appliquée. Prêt à démarrer.", presetIdFor(parts));
      } catch (error) {
        const messageText = error instanceof Error ? error.message : "Durée invalide.";
        return { ...state, status: messageText, tone: "error", feedbackTitle: "Durée invalide" };
      }
    }
    case "preset": {
      if (state.mode === "running") return state;
      const parts = partsFromSeconds(action.seconds);
      return commit(state, parts, action.now, "Durée prédéfinie sélectionnée.", action.id);
    }
    case "edit": {
      if (state.mode === "running") return state;
      if (state.draft[action.key] === action.value) return state;
      return {
        ...state,
        draft: { ...state.draft, [action.key]: action.value },
        presetId: null,
      };
    }
    default:
      return state;
  }
}

function isMode(value: unknown): value is Mode {
  return value === "idle" || value === "running" || value === "paused" || value === "done";
}

function isParts(value: unknown): value is DurationParts {
  if (!value || typeof value !== "object") return false;
  const record = value as Record<string, unknown>;
  try {
    const parts = {} as DurationParts;
    for (const key of FIELD_KEYS) {
      const n = record[key];
      if (typeof n !== "number") return false;
      parts[key] = n;
    }
    assertParts(parts);
    return true;
  } catch {
    return false;
  }
}

export function loadPersisted(): Persisted | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const data = JSON.parse(raw) as Partial<Persisted>;
    if (!isParts(data.parts) || !isMode(data.mode)) return null;
    if (data.theme !== "dark" && data.theme !== "light") return null;
    if (typeof data.remainingMs !== "number" || typeof data.initialMs !== "number") return null;
    return {
      theme: data.theme,
      sound: data.sound !== false,
      notify: data.notify === true,
      parts: data.parts,
      mode: data.mode,
      deadline: typeof data.deadline === "number" ? data.deadline : null,
      remainingMs: data.remainingMs,
      initialMs: data.initialMs,
    };
  } catch {
    return null;
  }
}

export function savePersisted(data: Persisted): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch {
    /* private mode / quota — the timer still works for this visit */
  }
}

let audioCtx: AudioContext | null = null;

export function unlockAudio(): void {
  const Ctx =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!Ctx) return;
  if (!audioCtx) audioCtx = new Ctx();
  if (audioCtx.state === "suspended") void audioCtx.resume();
}

export function playChime(): void {
  unlockAudio();
  const ctx = audioCtx;
  if (!ctx) return;
  const notes = [523.25, 659.25, 783.99, 1046.5];
  const start = ctx.currentTime + 0.02;
  notes.forEach((freq, i) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.value = freq;
    const t = start + i * 0.16;
    gain.gain.setValueAtTime(0.0001, t);
    gain.gain.exponentialRampToValueAtTime(0.18, t + 0.03);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.42);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(t);
    osc.stop(t + 0.46);
  });
}
