import { Capacitor } from '@capacitor/core';
import { LocalNotifications } from '@capacitor/local-notifications';

export const isAndroid = Capacitor.getPlatform() === 'android';
let queue = Promise.resolve();
export async function requestAndroidNotifications(): Promise<boolean> {
  const result = await LocalNotifications.requestPermissions();
  return result.display === 'granted';
}

// Serialize cancellation and replacement so a rapid pause/resume cannot leave an old alarm.
export function syncAndroidAlarm(deadline: number | null, sound: boolean): Promise<void> {
  queue = queue.catch(() => undefined).then(async () => {
    await LocalNotifications.cancel({ notifications: [{ id: 1 }] });
    if (deadline === null || deadline <= Date.now()) return;
    const permission = await LocalNotifications.checkPermissions();
    if (permission.display !== 'granted') return;
    const channelId = sound ? 'timeflow-alarm' : 'timeflow-silent';
    await LocalNotifications.createChannel({
      id: channelId,
      name: sound ? 'TimeFlow — Alarme' : 'TimeFlow — Silencieux',
      importance: 4,
      visibility: 1,
      vibration: sound,
      ...(sound ? {} : { sound: '' }),
    });
    await LocalNotifications.schedule({ notifications: [{
      id: 1,
      title: 'TimeFlow',
      body: 'Temps écoulé ! Votre compte à rebours est terminé.',
      channelId,
      schedule: { at: new Date(deadline), allowWhileIdle: true },
    }] });
  });
  return queue;
}
