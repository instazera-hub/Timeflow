import { createRoot } from 'react-dom/client';
import { TimeflowApp } from './components/timeflow-app';
import './styles.css';

export const siteName = 'TimeFlow';
export const siteDescription = 'Un minuteur précis et personnalisable, disponible sur Android et sur le web.';
createRoot(document.getElementById('root')!).render(<TimeflowApp />);
