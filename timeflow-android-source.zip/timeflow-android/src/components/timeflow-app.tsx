import { isAndroid, requestAndroidNotifications, syncAndroidAlarm } from "@/lib/android";
import { useEffect, useReducer, useRef, useState, type ReactNode } from "react";
import * as Dialog from "@radix-ui/react-dialog";
import * as Switch from "@radix-ui/react-switch";
import {
  AlarmClock,
  CalendarDays,
  Check,
  ChevronDown,
  ChevronRight,
  ChevronUp,
  Clock,
  Hourglass,
  Moon,
  Pause,
  Pencil,
  Play,
  RotateCcw,
  Settings,
  Shield,
  Smartphone,
  Sun,
  Target,
  Timer,
  X,
  Zap,
} from "lucide-react";
import {
  FIELD_KEYS,
  LIMITS,
  PRESETS,
  formatClock,
  initialTimerState,
  loadPersisted,
  playChime,
  reduceTimer,
  savePersisted,
  splitClock,
  unlockAudio,
  type FieldKey,
  type PresetIcon,
  type Theme,
} from "@/lib/timeflow";

const FIELD_META: { key: FieldKey; label: string; icon: "calendar" | "clock" }[] = [
  { key: "days", label: "Jours", icon: "calendar" },
  { key: "weeks", label: "Semaines", icon: "calendar" },
  { key: "months", label: "Mois", icon: "calendar" },
  { key: "hours", label: "Heures", icon: "clock" },
  { key: "minutes", label: "Minutes", icon: "clock" },
  { key: "seconds", label: "Secondes", icon: "clock" },
];

const FEATURES = [
  {
    icon: Target,
    title: "Précis et fiable",
    text: "Le compte à rebours est basé sur l'heure réelle de votre appareil pour une précision maximale.",
  },
  {
    icon: Smartphone,
    title: "Accessible partout",
    text: "Utilisez TimeFlow sur tous vos appareils : ordinateur, tablette et mobile.",
  },
  {
    icon: Zap,
    title: "Simple et efficace",
    text: "Une interface claire pour vous aider à rester concentré sur vos objectifs.",
  },
  {
    icon: Shield,
    title: "Vos données restent locales",
    text: "Aucune inscription requise. Tout reste sur votre appareil.",
  },
];

function presetGlyph(icon: PresetIcon) {
  const props = { className: "size-5", strokeWidth: 2.1, "aria-hidden": true as const };
  if (icon === "timer") return <Timer {...props} />;
  if (icon === "hourglass") return <Hourglass {...props} />;
  if (icon === "calendar") return <CalendarDays {...props} />;
  return <Clock {...props} />;
}

function Ring({ progress }: { progress: number }) {
  const p = Math.min(1, Math.max(0, progress));
  const r = 42;
  const c = 2 * Math.PI * r;
  const closed = p > 0.995;
  const dash = p <= 0 ? 0 : closed ? c : Math.max(0.8, c * p);
  const angle = -Math.PI / 2 + (closed ? 1 : p) * Math.PI * 2;
  const knob = { x: 50 + r * Math.cos(angle), y: 50 + r * Math.sin(angle) };
  return (
    <svg viewBox="0 0 100 100" className="tf-ring-glow size-64 sm:size-72 lg:size-80" aria-hidden="true">
      <defs>
        <linearGradient id="tfRing" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="var(--color-accent)" />
          <stop offset="100%" stopColor="var(--color-primary)" />
        </linearGradient>
      </defs>
      <circle cx="50" cy="50" r={r} fill="none" stroke="var(--color-ring-track)" strokeWidth="3.4" />
      {p > 0 ? (
        <circle
          className="tf-arc"
          cx="50"
          cy="50"
          r={r}
          fill="none"
          stroke="url(#tfRing)"
          strokeWidth="3.4"
          strokeLinecap={closed ? "butt" : "round"}
          strokeDasharray={`${dash} ${c}`}
          transform="rotate(-90 50 50)"
        />
      ) : null}
      {p > 0 ? (
        <g>
          <circle cx={knob.x} cy={knob.y} r="3.3" fill="var(--color-accent)" opacity="0.45" />
          <circle cx={knob.x} cy={knob.y} r="2.15" fill="var(--color-on-primary)" stroke="var(--color-accent)" strokeWidth="0.6" />
        </g>
      ) : null}
    </svg>
  );
}

function FloatingTimer({ progress, label }: { progress: number; label: string }) {
  const p = Math.min(1, Math.max(0, progress));
  const r = 42;
  const c = 2 * Math.PI * r;
  const dash = p <= 0 ? 0 : p > 0.995 ? c : Math.max(0.8, c * p);
  return (
    <button
      type="button"
      className="tf-float"
      aria-label={`Minuteur en cours, ${label}. Afficher le compte à rebours.`}
      onClick={() => document.getElementById("compte")?.scrollIntoView({ behavior: "smooth", block: "center" })}
    >
      <svg viewBox="0 0 100 100" className="tf-float-ring" aria-hidden="true">
        <circle cx="50" cy="50" r={r} fill="none" stroke="var(--color-ring-track)" strokeWidth="6" />
        {p > 0 ? (
          <circle
            className="tf-arc"
            cx="50"
            cy="50"
            r={r}
            fill="none"
            stroke="url(#tfRing)"
            strokeWidth="6"
            strokeLinecap={p > 0.995 ? "butt" : "round"}
            strokeDasharray={`${dash} ${c}`}
            transform="rotate(-90 50 50)"
          />
        ) : null}
      </svg>
      <span className="tf-float-time" data-long={label.length > 8}>
        {label}
      </span>
    </button>
  );
}

export function TimeflowApp() {
  const [timer, dispatch] = useReducer(reduceTimer, undefined, initialTimerState);
  const [theme, setTheme] = useState<Theme>("dark");
  const [sound, setSound] = useState(true);
  const [notify, setNotify] = useState(false);
  const [notifyNote, setNotifyNote] = useState("");
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [hydrated, setHydrated] = useState(false);
  const modeRef = useRef(timer.mode);

  useEffect(() => {
    const saved = loadPersisted();
    if (saved) {
      setTheme(saved.theme);
      setSound(saved.sound);
      setNotify(saved.notify);
      dispatch({ type: "hydrate", saved, now: Date.now() });
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
  }, [theme]);

  useEffect(() => {
    if (!hydrated) return;
    savePersisted({
      theme,
      sound,
      notify,
      parts: timer.parts,
      mode: timer.mode,
      deadline: timer.deadline,
      remainingMs: timer.remainingMs,
      initialMs: timer.initialMs,
    });
  }, [
    hydrated,
    theme,
    sound,
    notify,
    timer.parts,
    timer.mode,
    timer.deadline,
    timer.initialMs,
  ]);

  useEffect(() => {
    if (timer.mode !== "running") return;
    const tick = () => dispatch({ type: "tick", now: Date.now() });
    const id = window.setInterval(tick, 200);
    const onVis = () => {
      if (document.visibilityState === "visible") tick();
    };
    document.addEventListener("visibilitychange", onVis);
    return () => {
      window.clearInterval(id);
      document.removeEventListener("visibilitychange", onVis);
    };
  }, [timer.mode]);

  useEffect(() => {
    const previous = modeRef.current;
    modeRef.current = timer.mode;
    if (!hydrated || previous !== "running" || timer.mode !== "done") return;
    if (sound && !(isAndroid && notify)) playChime();
    if (!isAndroid && notify && typeof Notification !== "undefined" && Notification.permission === "granted") {
      try {
        new Notification("TimeFlow", {
          body: "Temps écoulé ! Votre compte à rebours est terminé.",
        });
      } catch {
        /* some browsers block notifications without a service worker icon */
      }
    }
  }, [timer.mode, hydrated, sound, notify]);

  useEffect(() => {
    if (timer.mode === "done") document.title = "Temps écoulé — TimeFlow";
    else document.title = `${formatClock(timer.remainingMs)} — TimeFlow`;
  }, [timer.mode, timer.remainingMs]);

  useEffect(() => {
    if (!("wakeLock" in navigator) || timer.mode !== "running") return;
    let lock: WakeLockSentinel | null = null;
    let dropped = false;
    const request = () => {
      navigator.wakeLock
        .request("screen")
        .then((next) => {
          if (dropped) void next.release();
          else lock = next;
        })
        .catch(() => undefined);
    };
    request();
    const onVis = () => {
      if (document.visibilityState === "visible") request();
    };
    document.addEventListener("visibilitychange", onVis);
    return () => {
      dropped = true;
      document.removeEventListener("visibilitychange", onVis);
      void lock?.release();
    };
  }, [timer.mode]);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target;
      if (target instanceof Element && target.closest("input, textarea, button, a, [role='dialog']")) return;
      if (event.key === " ") {
        event.preventDefault();
        if (timer.mode === "running") dispatch({ type: "pause", now: Date.now() });
        else if (timer.mode === "idle" || timer.mode === "paused") {
          unlockAudio();
          dispatch({ type: "start", now: Date.now() });
        }
      } else if ((event.key === "r" || event.key === "R") && !event.metaKey && !event.ctrlKey) {
        dispatch({ type: "reset", now: Date.now() });
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [timer.mode]);

  const progress = timer.initialMs > 0 ? timer.remainingMs / timer.initialMs : 0;
  const clock = splitClock(timer.remainingMs);
  const running = timer.mode === "running";

  function step(key: FieldKey, direction: 1 | -1) {
    const current = Number(timer.draft[key]);
    const base = Number.isInteger(current) ? current : 0;
    const next = Math.min(LIMITS[key], Math.max(0, base + direction));
    dispatch({ type: "edit", key, value: String(next) });
  }

  function blurField(key: FieldKey) {
    const raw = timer.draft[key].trim();
    if (raw === "") {
      dispatch({ type: "edit", key, value: "0" });
      return;
    }
    const value = Number(raw);
    if (!Number.isInteger(value)) return;
    dispatch({ type: "edit", key, value: String(Math.min(LIMITS[key], Math.max(0, value))) });
  }

  useEffect(() => {
    if (!isAndroid || !hydrated) return;
    void syncAndroidAlarm(notify && timer.mode === "running" ? timer.deadline : null, sound)
      .catch(() => setNotifyNote("Impossible de programmer l’alerte. Vérifiez les autorisations Android."));
  }, [hydrated, notify, timer.mode, timer.deadline, sound]);

  async function toggleNotify(next: boolean) {
    if (!next) {
      setNotify(false);
      setNotifyNote("");
      return;
    }
    if (isAndroid) {
      try {
        const granted = await requestAndroidNotifications();
        setNotify(granted);
        setNotifyNote(granted ? "" : "Autorisez les notifications dans les réglages Android.");
      } catch {
        setNotify(false);
        setNotifyNote("Impossible d’activer les notifications Android.");
      }
      return;
    }
    if (typeof Notification === "undefined") {
      setNotify(false);
      setNotifyNote("Les notifications ne sont pas disponibles sur cet appareil.");
      return;
    }
    const permission = await Notification.requestPermission();
    if (permission === "granted") {
      setNotify(true);
      setNotifyNote("");
    } else {
      setNotify(false);
      setNotifyNote("Les notifications sont bloquées dans le navigateur.");
    }
  }

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-20 flex items-center justify-between gap-3 border-b border-line bg-header/95 px-4 py-3 backdrop-blur-md sm:px-6">
        <div className="flex min-w-0 items-center gap-3">
          <Logo />
          <div className="flex min-w-0 items-center gap-3">
            <h1 className="text-2xl font-extrabold tracking-tight">
              Time<span className="text-accent">Flow</span>
            </h1>
            <span className="hidden h-4 w-px bg-line sm:block" aria-hidden="true" />
            <p className="hidden truncate text-sm text-muted sm:block">Votre temps, vos objectifs</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="tf-theme" role="group" aria-label="Thème">
            <button type="button" aria-label="Thème clair" aria-pressed={theme === "light"} onClick={() => setTheme("light")}>
              <Sun className="size-4" />
            </button>
            <button type="button" aria-label="Thème sombre" aria-pressed={theme === "dark"} onClick={() => setTheme("dark")}>
              <Moon className="size-4" />
            </button>
          </div>
          <Dialog.Root open={settingsOpen} onOpenChange={setSettingsOpen}>
            <Dialog.Trigger className="tf-gear" aria-label="Réglages">
              <Settings className="size-4" />
            </Dialog.Trigger>
            <Dialog.Portal>
              <Dialog.Overlay className="fixed inset-0 z-40 bg-black/60" />
              <Dialog.Content className="tf-card tf-modal fixed top-1/2 left-1/2 z-50 -translate-x-1/2 -translate-y-1/2 p-5">
                <div className="mb-4 flex items-start justify-between gap-3">
                  <div>
                    <Dialog.Title className="text-lg font-bold">Réglages</Dialog.Title>
                    <Dialog.Description className="mt-1 text-sm text-muted">
                      Le minuteur reste sur cet appareil. Rien n'est envoyé.
                    </Dialog.Description>
                  </div>
                  <Dialog.Close className="tf-gear" aria-label="Fermer">
                    <X className="size-4" />
                  </Dialog.Close>
                </div>
                <div className="grid gap-3">
                  <SettingRow
                    title="Alarme sonore"
                    text="Un carillon retentit quand le temps est écoulé."
                    checked={sound}
                    onCheckedChange={(value) => {
                      setSound(value);
                      if (value) unlockAudio();
                    }}
                  />
                  <SettingRow
                    title="Notification"
                    text="Afficher une alerte à la fin, même en arrière-plan sur Android."
                    checked={notify}
                    onCheckedChange={(value) => void toggleNotify(value)}
                  />
                  {notifyNote ? <p className="text-sm text-danger">{notifyNote}</p> : null}
                  <button
                    type="button"
                    className="tf-apply"
                    onClick={() => {
                      unlockAudio();
                      playChime();
                    }}
                  >
                    Tester l'alarme
                  </button>
                  <p className="text-sm text-muted">
                    Raccourcis : Espace pour démarrer ou mettre en pause, R pour réinitialiser.
                  </p>
                </div>
              </Dialog.Content>
            </Dialog.Portal>
          </Dialog.Root>
        </div>
      </header>

      {!isAndroid && <aside className="android-download" dir="rtl" aria-label="نسخة أندرويد">
        <div><strong>TimeFlow لأندرويد</strong><p>المشروع جاهز لبناء APK. يتضمن الملف إعدادات أندرويد وخطوات البناء؛ لا يحتوي على APK جاهز.</p></div>
        <a href="/downloads/timeflow-android-source.zip" download>تنزيل مشروع أندرويد</a>
        <a href="/android-guide.html">خطوات إنتاج APK</a>
      </aside>}
      <main className="mx-auto max-w-screen-2xl px-4 pt-5 pb-8 sm:px-6">
        <div className="grid items-stretch gap-4 lg:grid-cols-[minmax(16rem,0.92fr)_minmax(20rem,1.25fr)_minmax(18rem,1fr)]">
          <section className="tf-card order-2 p-5 lg:order-1" aria-labelledby="presets-title">
            <div className="mb-1 flex items-center gap-3">
              <span className="tf-icon">
                <Zap className="size-4" />
              </span>
              <h2 id="presets-title" className="text-lg font-bold">
                Durées prédéfinies
              </h2>
            </div>
            <p className="mb-4 text-sm text-muted">Choisissez une durée rapide ou personnalisez-la.</p>
            <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-1">
              {PRESETS.map((preset) => {
                const active = timer.presetId === preset.id;
                return (
                  <button
                    key={preset.id}
                    type="button"
                    className={active ? "tf-preset tf-preset-active" : "tf-preset"}
                    disabled={running}
                    aria-pressed={active}
                    onClick={() => dispatch({ type: "preset", id: preset.id, seconds: preset.seconds, now: Date.now() })}
                  >
                    <span className="tf-preset-glyph">{presetGlyph(preset.icon)}</span>
                    <span className="min-w-0 flex-1">
                      <span className="block text-sm font-bold">{preset.label}</span>
                      <span className="tf-preset-meta block text-xs">{formatClock(preset.seconds * 1000)}</span>
                    </span>
                    <ChevronRight className="tf-preset-chevron size-4" aria-hidden="true" />
                  </button>
                );
              })}
            </div>
          </section>

          <section id="compte" className="tf-card tf-stage order-1 px-4 py-8 lg:order-2" aria-label="Compte à rebours">
            <div className="relative grid place-items-center">
              <Ring progress={progress} />
              <div className="absolute inset-0 flex flex-col items-center justify-center px-10">
                <div className="mb-2 flex items-center gap-1.5 text-sm font-bold text-accent">
                  <Timer className="size-4" aria-hidden="true" />
                  Temps restant
                </div>
                <div
                  className="tf-clock"
                  data-long={clock.h.length >= 4}
                  role="timer"
                  aria-live="off"
                  aria-label={`Temps restant : ${formatClock(timer.remainingMs)}`}
                >
                  <span>{clock.h}</span>
                  <span>:</span>
                  <span>{clock.m}</span>
                  <span>:</span>
                  <span>{clock.s}</span>
                </div>
                <div className="mt-3 grid w-full max-w-56 grid-cols-3 text-xs text-muted">
                  <span>Heures</span>
                  <span>Minutes</span>
                  <span>Secondes</span>
                </div>
              </div>
            </div>

            <div
              className={
                timer.tone === "done" ? "tf-status tf-status-done mt-6" : timer.tone === "error" ? "tf-status tf-status-error mt-6" : "tf-status mt-6"
              }
              role="status"
              aria-live="polite"
            >
              {timer.tone === "done" ? (
                <AlarmClock className="size-4" aria-hidden="true" />
              ) : timer.mode === "paused" ? (
                <Pause className="size-4" aria-hidden="true" />
              ) : (
                <Play className="size-4" aria-hidden="true" />
              )}
              <span>{timer.status}</span>
            </div>

            <div className="mt-6 flex items-start justify-center gap-5">
              <Control
                label="Démarrer"
                disabled={running || timer.mode === "done"}
                hot={timer.mode !== "running" && timer.mode !== "done"}
                go
                onClick={() => {
                  unlockAudio();
                  dispatch({ type: "start", now: Date.now() });
                }}
              >
                <Play className="size-6" fill="currentColor" />
              </Control>
              <Control
                label="Pause"
                disabled={!running}
                hot={running}
                onClick={() => dispatch({ type: "pause", now: Date.now() })}
              >
                <Pause className="size-6" />
              </Control>
              <Control label="Réinitialiser" onClick={() => dispatch({ type: "reset", now: Date.now() })}>
                <RotateCcw className="size-6" />
              </Control>
            </div>
          </section>

          <section className="tf-card order-3 p-5" aria-labelledby="custom-title">
            <div className="mb-1 flex items-center gap-3">
              <span className="tf-icon">
                <Pencil className="size-4" />
              </span>
              <h2 id="custom-title" className="text-lg font-bold">
                Personnaliser la durée
              </h2>
            </div>
            <p className="mb-4 text-sm text-muted">
              Configurez votre propre durée en jours, semaines, mois, heures, minutes et secondes.
            </p>
            <form
              onSubmit={(event) => {
                event.preventDefault();
                dispatch({ type: "apply", now: Date.now() });
              }}
            >
              <div className="grid grid-cols-2 gap-3">
                {FIELD_META.map((field) => (
                  <label key={field.key} className="min-w-0">
                    <span className="mb-1.5 flex items-center gap-1.5 text-xs font-semibold text-accent">
                      {field.icon === "calendar" ? (
                        <CalendarDays className="size-3.5" aria-hidden="true" />
                      ) : (
                        <Clock className="size-3.5" aria-hidden="true" />
                      )}
                      {field.label}
                    </span>
                    <span className="tf-field">
                      <input
                        inputMode="numeric"
                        disabled={running}
                        aria-label={field.label}
                        value={timer.draft[field.key]}
                        onChange={(event) => dispatch({ type: "edit", key: field.key, value: event.target.value })}
                        onBlur={() => blurField(field.key)}
                      />
                      <span className="tf-spin">
                        <button
                          type="button"
                          aria-label={`Augmenter ${field.label}`}
                          disabled={running}
                          onClick={() => step(field.key, 1)}
                        >
                          <ChevronUp className="size-3" />
                        </button>
                        <button
                          type="button"
                          aria-label={`Diminuer ${field.label}`}
                          disabled={running}
                          onClick={() => step(field.key, -1)}
                        >
                          <ChevronDown className="size-3" />
                        </button>
                      </span>
                    </span>
                  </label>
                ))}
              </div>
              <button className="tf-apply mt-4" type="submit" disabled={running}>
                <Check className="size-4" />
                Appliquer la durée
              </button>
            </form>
            <div className={timer.tone === "error" ? "tf-feedback tf-feedback-bad mt-4" : "tf-feedback mt-4"}>
              <span className={timer.tone === "error" ? "tf-check tf-check-bad" : "tf-check"}>
                <Check className="size-4" />
              </span>
              <span>
                <strong className={timer.tone === "error" ? "block text-danger" : "block text-mint-2"}>
                  {timer.feedbackTitle}
                </strong>
                <small className="block text-muted">{timer.summary}</small>
              </span>
            </div>
          </section>
        </div>

        <section className="tf-card mt-4 grid gap-4 p-4 sm:grid-cols-2 xl:grid-cols-4" aria-label="Avantages de TimeFlow">
          {FEATURES.map((feature) => (
            <article key={feature.title} className="flex gap-3 px-1 py-1">
              <span className="tf-icon">
                <feature.icon className="size-4" />
              </span>
              <div>
                <h3 className="text-sm font-bold">{feature.title}</h3>
                <p className="mt-1 text-xs leading-relaxed text-muted">{feature.text}</p>
              </div>
            </article>
          ))}
        </section>
      </main>
      <footer className="border-t border-line px-4 py-5 text-center text-xs text-muted">
        TimeFlow · Un minuteur simple, puissant et toujours à vos côtés.
      </footer>
      {running ? <FloatingTimer progress={progress} label={formatClock(timer.remainingMs)} /> : null}
    </div>
  );
}

function Logo() {
  return (
    <svg className="size-11 shrink-0" viewBox="0 0 48 48" role="img" aria-label="Logo TimeFlow">
      <defs>
        <linearGradient id="tfLogo" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="var(--color-accent)" />
          <stop offset="1" stopColor="var(--color-primary)" />
        </linearGradient>
      </defs>
      <circle cx="24" cy="24" r="22" fill="url(#tfLogo)" />
      <circle cx="24" cy="26" r="11" fill="none" stroke="var(--color-on-primary)" strokeWidth="2.2" />
      <path d="M18 8h12M24 8v5M24 20v7l5 3" fill="none" stroke="var(--color-on-primary)" strokeWidth="2.2" strokeLinecap="round" />
    </svg>
  );
}

function Control({
  label,
  children,
  disabled,
  onClick,
  go,
  hot,
}: {
  label: string;
  children: ReactNode;
  disabled?: boolean;
  onClick: () => void;
  go?: boolean;
  hot?: boolean;
}) {
  return (
    <button type="button" className="tf-control grid justify-items-center gap-2 text-xs text-muted" disabled={disabled} onClick={onClick}>
      <span className={go ? (hot ? "tf-round tf-round-go tf-round-hot" : "tf-round tf-round-go") : hot ? "tf-round tf-round-hot" : "tf-round"}>
        {children}
      </span>
      {label}
    </button>
  );
}

function SettingRow({
  title,
  text,
  checked,
  onCheckedChange,
}: {
  title: string;
  text: string;
  checked: boolean;
  onCheckedChange: (value: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-xl border border-line px-3 py-3">
      <span>
        <span className="block text-sm font-semibold">{title}</span>
        <span className="block text-xs text-muted">{text}</span>
      </span>
      <Switch.Root className="tf-switch" checked={checked} onCheckedChange={onCheckedChange} aria-label={title}>
        <Switch.Thumb className="tf-switch-thumb" />
      </Switch.Root>
    </div>
  );
}
