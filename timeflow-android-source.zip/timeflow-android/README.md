# TimeFlow for Android

TimeFlow is a French countdown timer adapted from the supplied project into an offline Android app. It preserves presets, custom durations, pause/reset, light and dark themes, and device-local preferences. React, TypeScript, Tailwind CSS, Vite and Capacitor power the app; Capacitor Local Notifications supplies Android alerts. No hosted backend or account is needed.

## Run locally

Install Node.js 22, then run `npm ci` and `npm run dev`. For Android, install Android Studio with Android SDK 35 and Java 21. Run `npm run android:sync`, followed by `npm run android:open`. In Android Studio, choose Build → Build App Bundle(s) / APK(s) → Build APK(s). The debug APK appears in `android/app/build/outputs/apk/debug/app-debug.apk`.

## Produce an APK without a local Android installation

Upload the extracted project to a GitHub repository, including hidden `.github` files. Open Actions → Build Android APK → Run workflow. After success, download the `TimeFlow-debug-APK` artifact and extract `app-debug.apk`. Transfer it to an Android 6.0+ phone and allow installation from the app used to open it. This produces a debug APK for personal testing. Store distribution requires a signed release and a separately managed signing key.

No APK has been compiled or tested in the current environment. The web build pipeline validates the web app only. Android compilation and device verification remain necessary.

## Notifications

Enable Notification in TimeFlow settings and grant Android notification permission. Alarms are scheduled natively and canceled when paused or reset. Android battery management can delay alerts; exact-alarm permission is intentionally not requested. Force-stopping the app or restarting the phone can prevent pending alerts. Sound is configured per Android notification channel and can also be changed in system settings.

The original timer persists state in localStorage, retained here in the Android WebView. The countdown uses a timestamp and catches up after returning to the app. This is device-local app state, with no server database. The supplied unused server, authentication scaffolding and deployment-specific middleware are unnecessary for this timer and were not imported.
