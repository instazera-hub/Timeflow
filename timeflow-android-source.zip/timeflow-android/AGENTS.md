# Architecture

This repository adapts the supplied TimeFlow timer into a standalone Vite React client and a Capacitor 7 Android application. The existing French interface and timer reducer were retained. No TanStack server or authentication is needed by the actual timer.

- `src/main.tsx`: web/native React entry point.
- `src/components/timeflow-app.tsx`: original timer UI and lifecycle.
- `src/lib/timeflow.ts`: timer reducer, time calculations, existing device-local persistence and audio.
- `src/lib/android.ts`: serialized native notification scheduling and permissions.
- `src/styles.css`: original Tailwind theme and responsive styles.
- `android/`: generated native project, app ID `app.timeflow.timer`, SDK 35, minimum SDK 23.
- `capacitor.config.ts`: bundles `dist` into Android; no remote server URL.
- `.github/workflows/android-apk.yml`: manually triggered debug APK build, Java 21 and Node 22.
- `public/android-guide.html`: Arabic APK instructions.
- `scripts/package-source.py`: regenerates the downloadable source archive with an explicit file allowlist.

Use TypeScript for app code. Keep timer calculations in the pure reducer. Native calls must be guarded by platform detection; the web preview retains browser notifications. Never add signing keys to source. Run `npm run android:sync` after web changes before compiling Android. Native generated sync files are recreated by Capacitor. No compiled APK is committed, and the UI must not claim one exists. The existing localStorage state is deliberately retained because offline operation is the core Android behavior.
