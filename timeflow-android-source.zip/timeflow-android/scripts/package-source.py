"""Package distributable source only; never include environment files or build outputs."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
root = Path(__file__).resolve().parent.parent
files = ['package.json', 'package-lock.json', 'vite.config.ts', 'capacitor.config.ts',
         'index.html', 'netlify.toml', '.gitignore', 'README.md', 'AGENTS.md']
for folder in ['src', 'android', '.github/workflows', 'scripts']:
    for path in (root / folder).rglob('*'):
        rel = path.relative_to(root)
        if path.is_file() and not any(p in {'build', '.gradle', '.idea', '__pycache__'} for p in rel.parts) and path.name not in {'local.properties', '.DS_Store'}:
            files.append(str(rel))
files.extend(['public/favicon.svg', 'public/android-guide.html'])
out = root / 'public/downloads/timeflow-android-source.zip'
out.parent.mkdir(parents=True, exist_ok=True)
with ZipFile(out, 'w', ZIP_DEFLATED) as archive:
    for name in sorted(set(files)):
        archive.write(root / name, 'timeflow-android/' + name)
