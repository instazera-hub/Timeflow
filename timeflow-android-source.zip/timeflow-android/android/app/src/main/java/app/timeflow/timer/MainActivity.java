package app.timeflow.timer;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
